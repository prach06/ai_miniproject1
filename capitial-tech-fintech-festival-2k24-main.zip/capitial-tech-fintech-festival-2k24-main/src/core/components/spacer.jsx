
const Spacer = ({ height = 0, width = 0 }) => {
    return (
        <div style={{ width: width, height: height }}></div >
    )
}

export default Spacer